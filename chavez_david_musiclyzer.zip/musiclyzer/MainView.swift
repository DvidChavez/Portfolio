//
//  MainView.swift
//  musiclyzer
//
//  Created by mobile on 3/27/26.
//
import SwiftData
import SwiftUI
import Combine
internal import UniformTypeIdentifiers
import AVFoundation

struct MainView: View {
    @State private var presentImporter = false
    @State private var defaultTitles: [String] = ["Alright", "Dramatic Girl (feat. Che Ecru)"]
    @State private var songIndex: Int = 0
    
    @State private var artistName: [String] = []
    @State private var artworks: [Image] = [] // One image per song
    
    @StateObject private var artworkLoader = MP3ArtworkLoader()
    
    var defaultUrls: [URL] {
        defaultTitles.compactMap { name in
            Bundle.main.url(forResource: name, withExtension: "mp3")
        }
    }
    @State private var defaultSongs: [Song] = []
    
    //    init(titleFilter: String = "") {
    //        let predicate = #Predicate<String> { song in
    //            titleFilter.isEmpty || song.localizedStandardContains(titleFilter)
    //
    //            _bruh = Query(filter: predicate, sort: \bruh)
    //        }
    //    }
    
    
    var body: some View {
        NavigationStack {
            VStack {
                Spacer()
                Form {
//                    Section {
//                        HStack {
//                        }
//                    }
//                    VStack {
////                        Text("Songs of the Week")
////                            .frame(alignment: .init(horizontal: .leading, vertical: .center))
//                        
////                        ScrollView(. horizontal, showsIndicators: false) {
////                            HStack {
////                                if !defaultSongs.isEmpty {
////                                    ForEach(defaultSongs) { song in
////                                        songIndex = index
////                                        
////                                        NavigationLink(destination: MusicView(title: song.title, image: song.artwork, defaultTitles: $defaultTitles, song: song)) {
////                                            
////                                            song.artwork
////                                                .resizable()
////                                                .scaledToFit()
////                                                .frame(width: 120, height: 120)
////                                                .cornerRadius(8)
////                                                .shadow(color: .black, radius: 3)
////                                                .padding(1.5)
////                                        }
////                                    }
////                                }
////                            }
////                        }
////                        //.frame(maxWidth: 100, maxHeight: 100)
////                        .scrollTargetLayout()
//                        
//                        Text("Your Playlists")
//                            .frame(alignment: .init(horizontal: .leading, vertical: .center))
//                        
//                        
//                        //for num in 1..<10 {
//                        ScrollView(. horizontal, showsIndicators: false) {
//                            HStack{
////                                Rectangle()
////                                    .frame(width: 120, height: 120)
////                                    .cornerRadius(8)
//                            }
//                        } .scrollTargetLayout()
//                        //}
//                        
//                    }
//                    .scrollTargetBehavior(.viewAligned)
//                    
                    
                    Section {
                        
                        if !defaultSongs.isEmpty {
                            ForEach(defaultSongs) { song in
                                NavigationLink(destination: MusicView(title: song.title, artistName: song.artist, image: song.artwork, defaultTitles: $defaultTitles, song: song)) {
                                    
                                    song.artwork
                                        .resizable()
                                        .scaledToFit()
                                        .frame(width: 45, height: 45)
                                        .cornerRadius(3)

                                    VStack(alignment: .leading) {
                                        Text(song.title.replacingOccurrences(of: ".mp3", with: ""))
                                    }
                                    
                                }
                                .frame(maxWidth: .infinity, maxHeight: 25)
                                //.background(Color(.systemBackground).opacity(0.01))

                                
                            }
                        }
                    }
                    
                    .listRowSeparator(.hidden)
                    .listRowBackground(
                        Capsule()
                            .fill(Color(.systemGroupedBackground))
                            .padding()
                    )
                    //.clipped(antialiased: true)
                    //.aspectRatio(contentMode: .fill)
                    //.cornerRadius(8)
                    
                    
                }
               
            }
            .listSectionSeparator(.hidden)
            
            
            Button("Add music +") {
                presentImporter = true
            }
            .fileImporter(
                isPresented: $presentImporter,
                allowedContentTypes: [.mp3],
                allowsMultipleSelection: false
            ) { result in
                do {
                    let fileUrls = try result.get()

                    for fileUrl in fileUrls {
                        let filename = fileUrl.lastPathComponent

                        guard fileUrl.startAccessingSecurityScopedResource() else { continue }

                        let documentsDirectory = FileManager.default.urls(for: .documentDirectory, in: .userDomainMask).first!
                        let destinationURL = documentsDirectory.appendingPathComponent(filename)

                        if !FileManager.default.fileExists(atPath: destinationURL.path) {
                            try? FileManager.default.copyItem(at: fileUrl, to: destinationURL)
                        }

                        fileUrl.stopAccessingSecurityScopedResource()

                        //  sync init, async artwork load after
                        Task { @MainActor in
                            let song = Song(title: filename, artist: "Artist Name", url: destinationURL)
                            defaultSongs.append(song)
                            await song.loadArtwork() // loads and sets song.artwork
                        }
                    }

                } catch {
                    print("Error: \(error.localizedDescription)")
                }
            }
            
        }
        .navigationTitle("Your Music")
        .task {
            
            
            defaultSongs = [
                Song(title: "Billie Jean.mp3", artist: "Michael Jackson"),
                Song(title: "Get on the Floor.mp3", artist: "Michael Jackson"),
                Song(title: "Remember the Time.mp3", artist: "Michael Jackson")
            ]
            // Load artwork for each
            for song in defaultSongs {
                song.url = Bundle.main.url(forResource: song.title.replacingOccurrences(of: ".mp3", with: ""), withExtension: "mp3")!
                
                await song.loadAllArtworks(urls: [song.url])
                
            }
        }
    }
    
    
    
   
    
}

// MARK: - Safe array subscript
extension Collection {
    subscript(safe index: Index) -> Element? {
        indices.contains(index) ? self[index] : nil
    }
}

#Preview {
    MainView()
}
