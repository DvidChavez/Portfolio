////
////  Untitled.swift
////  musiclyzer
////
////  Created by mobile on 2/20/26.
////
//
//import Foundation
//import SwiftUI
//
//class TimerApplication: UIApplication {
//
//    private var timeoutInSeconds: TimeInterval {
//        return 40.0
//    }
//
//    private var idleTimer: Timer?
//    
//    override init() {
//        super.init()
//        resetIdleTimer()
//    }
//    
//    private func resetIdleTimer() {
//        if let idleTimer = idleTimer {
//            idleTimer.invalidate()
//        }
//
//        idleTimer = Timer.scheduledTimer(timeInterval: timeoutInSeconds,
//                                         target: self,
//                                         selector: #selector(TimerApplication.timeHasExceeded),
//                                         userInfo: nil,
//                                         repeats: false
//        )
//    }
//
//    @objc private func timeHasExceeded() {
//        NotificationCenter.default.post(name: .appTimeout, object: nil)
//    }
//
//    override func sendEvent(_ event: UIEvent) {
//
//        super.sendEvent(event)
//
//        if idleTimer != nil {
//            self.resetIdleTimer()
//        }
//
//        if let touches = event.allTouches {
//            for touch in touches where touch.phase == UITouch.Phase.began {
//                self.resetIdleTimer()
//            }
//        }
//    }
//}
