//AudioEngine.swift



import AVFoundation
import Accelerate
import Combine
import SwiftUI



class AudioEngine: ObservableObject {
    
    @Published var isPlaying = false
    @Published var currentTime: TimeInterval = 0.0
    @Published var bandPowers: [Float] = []   // multi‑band values for visualization
    

    private let engine = AVAudioEngine()
    private let playerNode = AVAudioPlayerNode()
    private var audioFile: AVAudioFile?
    private var displayLink: CADisplayLink?

    // FFT configuration
    private let fftSize: Int = 512     // must be power of 2
    private let numberOfBands: Int = 28     // how many bars you want
    private var fftSetup: FFTSetup?
    private var window: [Float] = []
    
//    @State private var bruh: [String] = ["Alright", "Dramatic Girl (feat. Che Ecru)"]
    
    init(song: Song) {
        bandPowers = Array(repeating: Float(-80), count: 28) // ← safe default, visible immediately
        setupEngine(song: song)
        setupFFT()
    }
    // MARK: - Engine setup

    private func setupEngine(song: Song = Song(title: "Billie Jean.mp3", artist: "Michael Jackson")) {
        
        
//        guard let url = Bundle.main.url(forResource: song, withExtension: "mp3") else { return }
        let url = song.url

        do {
            audioFile = try AVAudioFile(forReading: url)
        } catch {
            print("Error loading audio file: \(error)")
            return
        }

        guard let audioFile = audioFile else { return }

        engine.attach(playerNode)

        let mainMixer = engine.mainMixerNode
        let format = audioFile.processingFormat

        engine.connect(playerNode, to: mainMixer, format: format)

        // Install a tap on the mixer to get raw samples
        mainMixer.installTap(onBus: 0,
                             bufferSize: AVAudioFrameCount(fftSize/2),
                             format: mainMixer.outputFormat(forBus: 0)) { [weak self] buffer, _ in
            self?.analyzeBuffer(buffer: buffer)
        }

        do {
            try engine.start()
        } catch {
            print("Error starting engine: \(error)")
        }

        // Initialize bandPowers
        bandPowers = Array(repeating: -100, count: numberOfBands)
    }

    // MARK: - FFT setup

    private func setupFFT() {
        let log2n = vDSP_Length(log2(Float(fftSize)))
        fftSetup = vDSP_create_fftsetup(log2n, FFTRadix(kFFTRadix2))

        // Hann window to reduce spectral leakage
        window = [Float](repeating: 0, count: fftSize)
        vDSP_hann_window(&window, vDSP_Length(fftSize), Int32(vDSP_HANN_NORM))
    }

    // MARK: - Public controls

    func play() {
        guard let audioFile = audioFile else { return }

        if !engine.isRunning {
            try? engine.start()
        }

        playerNode.stop()
        playerNode.scheduleFile(audioFile, at: nil, completionHandler: nil)
        playerNode.play()
        isPlaying = true

        startDisplayLink()
    }

    func pause() {
        playerNode.pause()
        isPlaying = false
        stopDisplayLink()
    }

    func seek(to time: TimeInterval) {
        guard let audioFile = audioFile else { return }
        let sampleRate = audioFile.processingFormat.sampleRate
        let frame = AVAudioFramePosition(time * sampleRate)

        playerNode.stop()
        playerNode.scheduleSegment(audioFile,
                                   startingFrame: frame,
                                   frameCount: AVAudioFrameCount(audioFile.length - frame),
                                   at: nil,
                                   completionHandler: nil)
        playerNode.play()
    }

    func setVolume(_ value: Float) {
        playerNode.volume = value
    }

    // MARK: - Visualization timing

    private func startDisplayLink() {
        displayLink = CADisplayLink(target: self, selector: #selector(updateTime))
        displayLink?.add(to: .main, forMode: .common)
    }

    private func stopDisplayLink() {
        displayLink?.invalidate()
        displayLink = nil
    }

    @objc private func updateTime() {
        if let nodeTime = playerNode.lastRenderTime,
           let playerTime = playerNode.playerTime(forNodeTime: nodeTime) {
            let sampleRate = playerTime.sampleRate
            let samples = Double(playerTime.sampleTime)
            currentTime = samples / sampleRate
        }
    }

    // MARK: - FFT analysis

    private func analyzeBuffer(buffer: AVAudioPCMBuffer) {
        print("tap fired, frames: \(buffer.frameLength), channels: \(buffer.format.channelCount)")
        guard let channelData = buffer.floatChannelData?.pointee,
            let fftSetup = fftSetup
        else {
            return
        }

        let frameCount = Int(buffer.frameLength)
        if frameCount < fftSize/2 { return }

        // Use the first channel
        var samples = Array(UnsafeBufferPointer(start: channelData, count: min(frameCount, fftSize)))
        
        if samples.count < fftSize {
            samples += [Float](repeating: 0, count: fftSize - samples.count)
        }

        // Apply window
        vDSP_vmul(samples, 1, window, 1, &samples, 1, vDSP_Length(fftSize))

        // Prepare complex buffer
        var real = [Float](repeating: 0, count: fftSize/2)
        var imag = [Float](repeating: 0, count: fftSize/2)

        real.withUnsafeMutableBufferPointer { realPtr in
            imag.withUnsafeMutableBufferPointer { imagPtr in
                var splitComplex = DSPSplitComplex(realp: realPtr.baseAddress!,
                                                   imagp: imagPtr.baseAddress!)

                samples.withUnsafeBufferPointer { samplesPtr in
                    samplesPtr.baseAddress!.withMemoryRebound(to: DSPComplex.self, capacity: fftSize) { complexPtr in
                        vDSP_ctoz(complexPtr, 2, &splitComplex, 1, vDSP_Length(fftSize/2))
                    }

                    let log2n = vDSP_Length(log2(Float(fftSize)))
                    vDSP_fft_zrip(fftSetup,
                                  &splitComplex,
                                  1,
                                  log2n,
                                  FFTDirection(FFT_FORWARD))

                    // Magnitude
                    var magnitudes = [Float](repeating: 0, count: fftSize/2)
                    vDSP_zvmags(&splitComplex, 1, &magnitudes, 1, vDSP_Length(fftSize/2))

                    // Convert to dB
                    var zero: Float = 1.0
                    vDSP_vdbcon(magnitudes, 1, &zero, &magnitudes, 1,
                                vDSP_Length(fftSize/2), 0)  // ← 0 = power (10·log₁₀)

                    // Replace the band loop in analyzeBuffer:
                    var bands = [Float](repeating: 0, count: numberOfBands)
                    let sampleRate: Float = Float(audioFile?.processingFormat.sampleRate ?? 44100)
                    let nyquist = sampleRate / 2
                    let minFreq: Float = 20
                    let maxFreq: Float = 20000

                    var lastAssignedBin = 0  // tracks so no bin is ever skipped

                    for band in 0..<numberOfBands {
                        let lowFreq  = minFreq * pow(maxFreq / minFreq, Float(band)     / Float(numberOfBands))
                        let highFreq = minFreq * pow(maxFreq / minFreq, Float(band + 1) / Float(numberOfBands))
                        
                        let rawHigh = Int((highFreq / nyquist) * Float(fftSize / 2))
                        
                        // Always advance at least one bin so no band is ever empty
                        let start = lastAssignedBin
                        let end   = max(start + 1, min(rawHigh, fftSize / 2))
                        lastAssignedBin = end
                        
                        if end > magnitudes.count { break }
                        
                        var avg: Float = 0
                        vDSP_meanv(Array(magnitudes[start..<end]), 1, &avg, vDSP_Length(end - start))
                        bands[band] = avg
                    }
                    let capturedBands = bands
                    Task { @MainActor [weak self] in
                        self?.bandPowers = capturedBands
                    }

                }
            }
        }
    }
}
