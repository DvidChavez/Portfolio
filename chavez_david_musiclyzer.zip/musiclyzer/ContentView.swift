

//ContentView

import SwiftUI
import Combine
internal import UniformTypeIdentifiers


struct ContentView: View {
    @State private var searchText = ""
    
    var body: some View {
        NavigationView {
            MainView()
        }
    }
}

//// MARK: - Safe array subscript
//extension Collection {
//    subscript(safe index: Index) -> Element? {
//        indices.contains(index) ? self[index] : nil
//    }
//}

#Preview {
    ContentView()
}
