//
//  MusicView.swift
//  musiclyzer
//
//  Created by mobile on 2/20/26.
//



//MusicView

import SwiftUI
import Combine
internal import UniformTypeIdentifiers


struct MusicView : View {
    
    @StateObject private var artworkLoader = MP3ArtworkLoader()
    var title: String = "<p>Song Name</p>"
    var image: Image
    var artistName: String = "<p>Artist Name</p>"
    
    @StateObject private var engine: AudioEngine
    @Binding var defaultTitles: [String]
    
    var myTimer: Timer?
    @State var scrollingSpeed: CGFloat = 2
    var spacing: CGFloat = 10
    var itemWidth: CGFloat = 20

    @State private var sizeStretch: CGFloat = 0.8
    
    @State private var scrollPosition: ScrollPosition = .init()
    @State private var containerWidth: CGFloat = 0
    @State private var currentOffset: CGFloat = 0
    @State private var repeatingCount: Int = 0
    
    init(title: String, artistName: String, image: Image, defaultTitles: Binding<[String]>, song: Song) {
        self.title = title
        self.artistName = artistName
        self.image = image
        self._defaultTitles = defaultTitles
        self._engine = StateObject(wrappedValue: AudioEngine(song: song))
    
    }

    var body: some View {

        ZStack{
            Rectangle().background().edgesIgnoringSafeArea(.all)
            Rectangle().colorInvert().edgesIgnoringSafeArea(.all).opacity(0.867)
                
            VStack{
                
                ZStack{
                    VStack{
                        if engine.isPlaying {
                            image
                                .resizable()
                                .scaledToFit()
                                .cornerRadius(8)
                                .opacity(engine.isPlaying ? 1: 0.0)
                            //.animation(.easeInOut(duration: 0.2), value: engine.isPlaying )
                                .blur(radius: 100)
                                .scaleEffect(sizeStretch)
                        }
                        Spacer()
                    }
                    
                    VStack{
                        image
                            .resizable()
                            .scaledToFit()
                            .cornerRadius(8)
                            .shadow(color: .black, radius: 10)
                            .scaleEffect(engine.isPlaying ? sizeStretch - 0.2: sizeStretch)
                            .animation(.easeInOut(duration: 0.2), value: engine.isPlaying )
                        Spacer()
                    }
                    
                    VStack(alignment: .center){
                        
                        ScrollView(.horizontal, showsIndicators: false) {
                            HStack(spacing: spacing){
                                
                                let multiplier = 7.5
                                ///original audio frequency bars
                                HStack(spacing: spacing) {
                                    
//                                    ForEach(engine.bandPowers.indices, id: \.self) { i in
//                                        let height = max(0, CGFloat(engine.bandPowers[i]) * multiplier)
//                                        RoundedRectangle(cornerRadius: 25.0)
//                                            .glassEffect(.regular.interactive())
//                                            .frame(width: itemWidth, height: height)
//                                            .animation(.spring(response: 0.15, dampingFraction: 1.0), value: height)
//                                            //.spring(response: 0.04, dampingFraction: 1.0)
//                                        
//                                    }
//                                    
//                                    
                                    ForEach(0..<3, id: \.self) { _ in
                                        HStack(spacing: spacing) {
                                            ForEach(engine.bandPowers.indices, id: \.self) { i in
                                                let height = max(0, CGFloat(engine.bandPowers[i]) * multiplier)
                                                RoundedRectangle(cornerRadius: 25.0)
                                                    .glassEffect(.regular.interactive())
                                                    .frame(width: itemWidth, height: height)
                                                    .animation(.spring(response: 0.2, dampingFraction: 1.0), value: height)
                                            }
                                        }
                                    }
                                }
                                
//                                let barHeights = engine.bandPowers.map { band -> CGFloat in
//                                    return max(0, CGFloat(band) * multiplier)
//                                }
//                                
//                                let _ = print(barHeights.map{Int($0)})
//                                repeating frequency bars
//                                
//                                ForEach(engine.bandPowers.indices, id: \.self) { i in
//                                    let height = max(0, CGFloat(engine.bandPowers[i]) * multiplier)
//                                    RoundedRectangle(cornerRadius: 25.0)
//                                        .glassEffect(.regular.interactive())
//                                        .frame(width: itemWidth, height: height)
//                                        .animation(.spring(response: 0.15, dampingFraction: 1.0), value: height)
//                                        
//                                    
//                                }
                                
                            }
                            .scrollTargetLayout()
                            .frame(maxWidth: .infinity, maxHeight: .infinity, alignment: .init(horizontal: .center, vertical: .center))
                            
                        }
                        .scrollPosition($scrollPosition)
                        .onScrollGeometryChange(for: CGFloat.self) {
                            $0.containerSize.width
                        } action: { oldValue, newValue in
                            self.containerWidth = newValue
                        }
                        .onScrollGeometryChange(for: CGFloat.self) {
                            $0.contentOffset.x + $0.contentInsets.leading
                        } action: { oldValue, newValue in
                            currentOffset = newValue

                            let barCount = CGFloat(engine.bandPowers.count)
                            let oneGroupWidth = barCount * (itemWidth + spacing)

                            var transaction = Transaction()
                            transaction.scrollPositionUpdatePreservesVelocity = true

                            if newValue >= oneGroupWidth * 2 {
                                withTransaction(transaction) {
                                    scrollPosition.scrollTo(x: newValue - oneGroupWidth)
                                }
                            } else if newValue < oneGroupWidth {
                                withTransaction(transaction) {
                                    scrollPosition.scrollTo(x: newValue + oneGroupWidth)
                                }
                            }
                        }
                        .simultaneousGesture(
                            DragGesture(minimumDistance: 0)
                                .onChanged { _ in scrollingSpeed = 0 }
                                .onEnded   { _ in scrollingSpeed = 2 }
                        )
                        .scrollTargetBehavior(.viewAligned)
                        .onReceive(Timer.publish(every: 0.01, on: .main, in: .default).autoconnect()) { _ in
                            guard engine.isPlaying else { return }
                            scrollPosition.scrollTo(x: currentOffset + scrollingSpeed)
                        }
                        .onAppear {
                            let barCount = CGFloat(engine.bandPowers.count)
                            let oneGroupWidth = barCount * (itemWidth + spacing)
                            currentOffset = oneGroupWidth
                            scrollPosition.scrollTo(x: oneGroupWidth)
                        }
                        //Spacer()
                        let newTitle = title.replacingOccurrences(of: ".mp3", with: "")
                        Text(newTitle)
                            .bold()
                            .font(.title)
                            .opacity(0)
                        Text("by " + artistName)
                            .opacity(0)
                        Spacer()

                        Button {
                            engine.isPlaying ? engine.pause() : engine.play()
                        } label: {
                            Image(systemName: engine.isPlaying ? "pause.circle.fill" : "play.circle.fill")
                                .font(.system(size: 80))
                                .scaleEffect(engine.isPlaying ? 1.1: 1.0)
                                .opacity(0)
                            
                            
                        }
                        
                    }
                
                    
                    VStack() {
                        
                        Spacer()
                        Spacer()
                        Spacer()
                        Spacer()
                        Spacer()
                        let newTitle = title.replacingOccurrences(of: ".mp3", with: "")
                        Text(newTitle)
                            .bold()
                            .font(.title)
                        Text("by " + artistName)
                        Spacer()

                        Button {
                            engine.isPlaying ? engine.pause() : engine.play()
                        } label: {
                            Image(systemName: engine.isPlaying ? "pause.circle.fill" : "play.circle.fill")
                                .font(.system(size: 80))
                                .foregroundStyle(.white)
                                .shadow(color: .white.opacity(0.5),  radius: 10)
                                .scaleEffect(engine.isPlaying ? 1.1: 1.0)
                                .animation(.spring(response: 0.5, dampingFraction: 0.5), value: engine.isPlaying)
                            
                            
                        }
                        //Slider(value: $sizeStretch)
                    }
                    Spacer()
                }
            }
        }
    }
    
    func normalized(_ power: Float) -> CGFloat {
        let minDb: Float = -60
        let normalized = (power - minDb) / (0 - minDb)
        return CGFloat(max(0,min(normalized, 1)))
    }
    
    func formatTime(_ time: TimeInterval) -> String{
        let minutes = Int(time) / 60
        let seconds = Int(time) % 60
        
        return String(format: "%d: %02d", minutes, seconds)
    }
    func clearScreen() {
        
    }
}

#Preview {
    @Previewable @State var defaultTitles = ["Alright"]
    MusicView(title: "Billie Jean", artistName: "Michael Jackson", image: Image(systemName: "music.note"), defaultTitles: $defaultTitles, song:Song(title: "", artist: ""))
}
