//artworkLoader 2/20/26
//swift.ui

import AVFoundation
import SwiftUI
import Combine

@MainActor
class MP3ArtworkLoader: ObservableObject {
    
    @Published var image: Image = Image(systemName: "music.note")
    
    func loadArtwork(from url: URL) async -> Image {
        do {
            let asset = AVURLAsset(url: url)
            
            // Load metadata
            let metadata = try await asset.load(.commonMetadata)
            
            // Filter for artwork items
            let artworkItems = AVMetadataItem.metadataItems(
                from: metadata,
                withKey: AVMetadataKey.commonKeyArtwork,
                keySpace: .common
            )
            
            // Load dataValue async for each item
            for item in artworkItems {
                let data = try await item.load(.dataValue)
                if let uiImage = UIImage(data: data!) {
                    self.image = Image(uiImage: uiImage)
                }
            }
            
        } catch {
            print("Failed to load artwork: \(error.localizedDescription)")
        }
        return self.image
    }
    
    func getMP3Info(forResource fileName: String, ofType fileType: String) async -> [String: String] {
        var metadata: [String: String] = ["":""]

        // 1. Get the URL for the file in the app bundle
        guard let url = Bundle.main.url(forResource: fileName, withExtension: fileType) else {
            print("File not found")
            return metadata
        }

        // 2. Create an AVAsset
        let asset = AVURLAsset(url: url)

        do {
            // 3. Load the common metadata asynchronously
            let commonMetadata = try await asset.load(.commonMetadata)

            // 4. Iterate over the metadata items and extract relevant info
            for item in commonMetadata {
                if let key = item.commonKey?.rawValue, let value = try await item.load(.value) as? String {
                    metadata[key] = value
                }
            }

            // Duration can be accessed via a separate property
            let duration = try await asset.load(.duration)
            metadata["duration"] = CMTimeGetSeconds(duration).description

        } catch {
            print("Error loading meta\(error.localizedDescription)")
        }

        return metadata
    }

}
