//
//  Song.swift
//  musiclyzer
//
//  Created by mobile on 3/27/26.
//

import Foundation
import SwiftData
import SwiftUI
internal import System

//@Model
@Observable
class Song: @unchecked Sendable, Identifiable {
    var title: String
    var artist: String
    var url: URL
    var artwork: Image = Image(systemName: "music.note")
    var id: String { title }
    var artworks = [] as [Image]

    //  Sync init — no async, no fatalError
    init(title: String, artist: String, url: URL = URL(string: "Bundle")!) {
        self.title = title//.replacingOccurrences(of: ".mp3", with: "")
        self.artist = artist

        if url == URL(string: "Bundle")! {
            self.url = Bundle.main.url(forResource: title.replacingOccurrences(of: ".mp3", with: ""), withExtension: "mp3")!
        } else {
            self.url = url
        }
    }

    //  Call this separately after init
    func loadArtwork() async {
        let loader = MP3ArtworkLoader()
        let image = await loader.loadArtwork(from: url)
        await MainActor.run {
            self.artwork = image
        }
    }
    
    @MainActor
    func loadAllArtworks(urls: [URL]) async {
        let loader = MP3ArtworkLoader()
        artworks = Array(repeating: Image(systemName: "music.note"), count: urls.count)
        
        for (index, url) in urls.enumerated() {
            let image = await loader.loadArtwork(from: url)
            artworks[index] = image
        }
        // Also set the primary artwork from self.url
        artwork = await loader.loadArtwork(from: self.url)
    }
    
//    @MainActor
//    func loadAllArtworks(urls : [URL]) async {
//        let validUrls = urls
//        artworks = Array(repeating: Image(systemName: "music.note"), count: validUrls.count)
//
//        await loadArtwork()
//
//    }
}
//    static let SampleData = [
//        Song(name: "ALright", artist: "Kendrick Lamar"),
//        Song(name: "House Money", artist: "Baby Keem")
//    ]
//}

