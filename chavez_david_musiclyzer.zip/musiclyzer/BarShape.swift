//
//  BarShape.swift
//  musiclyzer
//
//  Created by Mobile on 2/12/26.
//

import SwiftUI

struct BarShape: Shape {

    let magnitude: CGFloat
    
    func path(in rect: CGRect) -> Path {
        var path = Path()
        let height = rect.height * magnitude
        let y = rect.height - height
        path.addRect(CGRect(x: 0, y: y, width: rect.width, height: height))
        return path
    }
}
