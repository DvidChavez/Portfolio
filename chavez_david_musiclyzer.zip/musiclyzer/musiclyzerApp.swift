//
//  musiclyzerApp.swift
//  musiclyzer
//
//  Created by Mobile on 2/6/26.
//

import SwiftUI

@main
struct musiclyzerApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
